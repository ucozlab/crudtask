<div id="footer">
    <div class="container">
        <p class="muted credit">&copy; Екатерина Бондуровская 2016</p>
    </div>
</div>
